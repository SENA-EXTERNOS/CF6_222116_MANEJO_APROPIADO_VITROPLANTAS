function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6URWSJ9UMeU":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

